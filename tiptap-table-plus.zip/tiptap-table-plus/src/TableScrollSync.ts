import { Extension } from "@tiptap/core";
import { Plugin, PluginKey } from "prosemirror-state";
import { EditorView } from "prosemirror-view";

export type TableScrollState = {
  tables: Map<string, {
    scrollLeft: number;
    timestamp: number;
    listeners: Set<(scrollLeft: number) => void>;
  }>;
};

export type TableScrollAPI = {
  getTableScrollPosition: (tableId: string) => number;
  setTableScrollPosition: (tableId: string, scrollLeft: number) => void;
  addScrollListener: (tableId: string, listener: (scrollLeft: number) => void) => () => void;
  removeScrollListener: (tableId: string, listener: (scrollLeft: number) => void) => void;
  registerTable: (tableId: string) => void;
};

class TableScrollView {
  private state: TableScrollState;

  constructor(private view: EditorView) {
    this.state = {
      tables: new Map()
    };
  }

  public registerTable(tableId: string) {
    if (!this.state.tables.has(tableId)) {
      this.state.tables.set(tableId, {
        scrollLeft: 0,
        timestamp: 0,
        listeners: new Set()
      });
    }
  }

  public getTableScrollPosition(tableId: string): number {
    return this.state.tables.get(tableId)?.scrollLeft ?? 0;
  }

  public setTableScrollPosition(tableId: string, scrollLeft: number) {
    const tableState = this.state.tables.get(tableId);
    if (!tableState) {
      // Auto-register if not found
      this.registerTable(tableId);
      return this.setTableScrollPosition(tableId, scrollLeft);
    }

    // Update state
    tableState.scrollLeft = scrollLeft;
    tableState.timestamp = Date.now();

    // Notify all listeners
    tableState.listeners.forEach(listener => {
      try {
        listener(scrollLeft);
      } catch (e) {
        console.warn('Table scroll listener error:', e);
      }
    });
  }

  public addScrollListener(tableId: string, listener: (scrollLeft: number) => void): () => void {
    let tableState = this.state.tables.get(tableId);
    if (!tableState) {
      this.registerTable(tableId);
      tableState = this.state.tables.get(tableId)!;
    }

    tableState.listeners.add(listener);
    
    // Return cleanup function
    return () => {
      const currentTableState = this.state.tables.get(tableId);
      if (currentTableState) {
        currentTableState.listeners.delete(listener);
      }
    };
  }

  public removeScrollListener(tableId: string, listener: (scrollLeft: number) => void) {
    const tableState = this.state.tables.get(tableId);
    if (tableState) {
      tableState.listeners.delete(listener);
    }
  }

  public getState(): TableScrollState {
    return this.state;
  }

  public destroy() {
    // Clean up all listeners
    this.state.tables.forEach(tableState => {
      tableState.listeners.clear();
    });
    this.state.tables.clear();
  }
}

export const tableScrollSyncPluginKey = new PluginKey("TableScrollSync");

type TableScrollStorage = {
  view: TableScrollView | undefined;
};

export const TableScrollSyncExtension = Extension.create<{}>({
  name: "tableScrollSync",

  addStorage(): TableScrollStorage {
    return {
      view: undefined,
    };
  },

  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: tableScrollSyncPluginKey,
        view: (editorView) => {
          this.storage.view = new TableScrollView(editorView);
          return this.storage.view;
        },
      }),
    ];
  },

  onCreate() {
    // Attach API methods to editor
    const api: TableScrollAPI = {
      getTableScrollPosition: (tableId: string) => {
        return this.storage.view?.getTableScrollPosition(tableId) ?? 0;
      },

      setTableScrollPosition: (tableId: string, scrollLeft: number) => {
        this.storage.view?.setTableScrollPosition(tableId, scrollLeft);
      },

      addScrollListener: (tableId: string, listener: (scrollLeft: number) => void) => {
        if (!this.storage.view) {
          return () => {}; // Return no-op cleanup
        }
        return this.storage.view.addScrollListener(tableId, listener);
      },

      removeScrollListener: (tableId: string, listener: (scrollLeft: number) => void) => {
        this.storage.view?.removeScrollListener(tableId, listener);
      },

      registerTable: (tableId: string) => {
        this.storage.view?.registerTable(tableId);
      },
    };

    // Make API available on editor instance
    (this.editor as any).tableScrollSync = api;
  },

  onDestroy() {
    this.storage.view?.destroy();
  },
});

export default TableScrollSyncExtension;