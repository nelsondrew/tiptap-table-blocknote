import { Table } from "@tiptap/extension-table";
import { mergeAttributes } from "@tiptap/core";
import { DOMOutputSpec } from "@tiptap/pm/model";
import { TableRowGroup } from "./TableRowGroup";
import TableCommandExtension from "../TableCommandExtension";


export const TablePlus = Table.extend({
  content: "(tableRowGroup|tableRow)+",
  addExtensions() {
    return [
      TableRowGroup,
      TableCommandExtension
    ]
  },
  renderHTML({ node, HTMLAttributes }) {
    const table: DOMOutputSpec = [
      "table",
      mergeAttributes(this.options.HTMLAttributes, HTMLAttributes, {
        border: 1,
      }),
      0,
    ];
    return table;
  },
  addNodeView() {
    return ({ node, editor, getPos }) => {
      const dom = document.createElement('table');
      let maxCellCount = 0;
      
      // Calculate max cell count
      node.forEach((child: any) => {
        if (child.type.name === 'tableRowGroup') {
          child.forEach((row: any) => {
            if (row.type.name === 'tableRow') {
              if(row.childCount > maxCellCount) {
                maxCellCount = row.childCount;
              }
            }
          });
        } else if (child.type.name === 'tableRow') {
          if(child.childCount > maxCellCount) {
            maxCellCount = child.childCount;
          }
        }
      });
      
      dom.style.setProperty('--cell-count', maxCellCount.toString());
      dom.classList.add('table-plus');
      
      // Generate unique table ID and register with scroll sync
      const tableId = `table-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      dom.dataset.tableId = tableId;
      
      // Register table with scroll sync extension
      if ((editor as any).tableScrollSync) {
        (editor as any).tableScrollSync.registerTable(tableId);
      }
      
      // Add resize functionality
      let resizing = false;
      let startX = 0;
      let startWidth = 0;
      let resizingColumnIndex = -1;
      
      const addResizeHandles = () => {
        // Remove existing handles
        dom.querySelectorAll('.column-resize-handle').forEach(handle => handle.remove());
        
        // Add resize handles to header cells
        const headerRow = dom.querySelector('tr');
        if (headerRow) {
          const cells = headerRow.querySelectorAll('th, td');
          cells.forEach((cell: any, index) => {
            if (index < cells.length - 1) { // Don't add handle to last column
              const handle = document.createElement('div');
              handle.className = 'column-resize-handle';
              handle.style.cssText = `
                position: absolute;
                top: 0;
                right: -2px;
                bottom: 0;
                width: 4px;
                background: transparent;
                cursor: col-resize;
                z-index: 10;
                user-select: none;
              `;
              
              handle.addEventListener('mousedown', (e) => {
                e.preventDefault();
                resizing = true;
                startX = e.clientX;
                resizingColumnIndex = index;
                
                // Get current width
                const rect = cell.getBoundingClientRect();
                startWidth = rect.width;
                
                handle.style.background = '#667eea';
                document.body.style.cursor = 'col-resize';
                document.body.style.userSelect = 'none';
              });
              
              cell.style.position = 'relative';
              cell.appendChild(handle);
            }
          });
        }
      };
      
      let currentWidth = 0;
      
      const handleMouseMove = (e: MouseEvent) => {
        if (!resizing || resizingColumnIndex === -1) return;
        
        const diff = e.clientX - startX;
        const newWidth = Math.max(50, startWidth + diff); // Minimum width of 50px
        currentWidth = newWidth;
        
        // Visual feedback only - update grid template directly for smooth resizing
        const rows = dom.querySelectorAll('tr');
        rows.forEach((row: any) => {
          const currentTemplate = row.style.gridTemplateColumns;
          if (currentTemplate) {
            const columns = currentTemplate.split(' ');
            if (columns[resizingColumnIndex]) {
              columns[resizingColumnIndex] = `${newWidth}px`;
              row.style.gridTemplateColumns = columns.join(' ');
            }
          }
        });
      };
      
      const updateDocumentWithNewWidth = (newWidth: number) => {
        // Update the ProseMirror document only once when resizing is complete
        const pos = getPos();
        if (typeof pos === 'number') {
          const { tr } = editor.state;
          const tableNode = editor.state.doc.nodeAt(pos);
          
          if (tableNode) {
            let updatedTable = tableNode;
            
            // Update colwidth for all rows
            tableNode.forEach((child: any, childOffset: number) => {
              if (child.type.name === 'tableRowGroup') {
                let updatedRowGroup = child;
                child.forEach((row: any, rowOffset: number) => {
                  if (row.type.name === 'tableRow') {
                    let updatedRow = row;
                    row.forEach((cell: any, cellOffset: number) => {
                      if (cellOffset === resizingColumnIndex) {
                        const currentColwidths = cell.attrs.colwidth || [];
                        const newColwidths = [...currentColwidths];
                        newColwidths[0] = newWidth;
                        
                        const updatedCell = cell.type.create(
                          { ...cell.attrs, colwidth: newColwidths },
                          cell.content
                        );
                        updatedRow = updatedRow.replaceChild(cellOffset, updatedCell);
                      }
                    });
                    updatedRowGroup = updatedRowGroup.replaceChild(rowOffset, updatedRow);
                  }
                });
                updatedTable = updatedTable.replaceChild(childOffset, updatedRowGroup);
              } else if (child.type.name === 'tableRow') {
                let updatedRow = child;
                child.forEach((cell: any, cellOffset: number) => {
                  if (cellOffset === resizingColumnIndex) {
                    const currentColwidths = cell.attrs.colwidth || [];
                    const newColwidths = [...currentColwidths];
                    newColwidths[0] = newWidth;
                    
                    const updatedCell = cell.type.create(
                      { ...cell.attrs, colwidth: newColwidths },
                      cell.content
                    );
                    updatedRow = updatedRow.replaceChild(cellOffset, updatedCell);
                  }
                });
                updatedTable = updatedTable.replaceChild(childOffset, updatedRow);
              }
            });
            
            const transaction = tr.replaceWith(pos, pos + tableNode.nodeSize, updatedTable);
            editor.view.dispatch(transaction);
          }
        }
      };
      
      const handleMouseUp = () => {
        if (resizing) {
          // Update document with final width
          updateDocumentWithNewWidth(currentWidth);
          
          resizing = false;
          resizingColumnIndex = -1;
          document.body.style.cursor = '';
          document.body.style.userSelect = '';
          
          // Reset handle color
          dom.querySelectorAll('.column-resize-handle').forEach((handle: any) => {
            handle.style.background = 'transparent';
          });
        }
      };
      
      // Add scroll delegation handler for all row wrappers
      let scrollTimeout: NodeJS.Timeout | null = null;
      let isUpdatingFromSync = false;
      
      const handleTableScroll = (e: Event) => {
        const target = e.target as HTMLElement;
        
        // Check if the scroll event is from a table-row-wrapper
        if (target.classList.contains('table-row-wrapper')) {
          if (!isUpdatingFromSync && tableId && (editor as any).tableScrollSync) {
            // Clear previous timeout
            if (scrollTimeout) {
              clearTimeout(scrollTimeout);
            }
            
            // Immediate update for responsive feel
            (editor as any).tableScrollSync.setTableScrollPosition(tableId, target.scrollLeft);
            
            // Also set a final update after scrolling stops (for accuracy)
            scrollTimeout = setTimeout(() => {
              if (!isUpdatingFromSync && tableId && (editor as any).tableScrollSync) {
                (editor as any).tableScrollSync.setTableScrollPosition(tableId, target.scrollLeft);
              }
            }, 50);
          }
        }
      };
      
      // Listen for scroll changes from other rows
      let cleanupScrollListener: (() => void) | null = null;
      
      const setupTableScrollSync = () => {
        if (tableId && (editor as any).tableScrollSync) {
          cleanupScrollListener = (editor as any).tableScrollSync.addScrollListener(
            tableId,
            (scrollLeft: number) => {
              // Sync all row wrappers in this table
              const rowWrappers = dom.querySelectorAll('.table-row-wrapper');
              rowWrappers.forEach((wrapper: any) => {
                if (Math.abs(wrapper.scrollLeft - scrollLeft) > 0.5) {
                  isUpdatingFromSync = true;
                  wrapper.scrollLeft = scrollLeft;
                  setTimeout(() => { isUpdatingFromSync = false; }, 10);
                }
              });
            }
          );
        }
      };
      
      // Add event delegation for scroll events
      dom.addEventListener('scroll', handleTableScroll, true); // Use capture phase
      
      // Setup scroll sync after DOM is ready
      setTimeout(setupTableScrollSync, 0);
      
      // Add global event listeners
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      
      // Initial setup
      setTimeout(addResizeHandles, 100);
      
      return {
        dom,
        contentDOM: dom,
        ignoreMutation(mutation: MutationRecord) {
          return document.querySelector('.column-resize-handle') !== null;
        },
        update(updatedNode: any) {
          if (updatedNode.type.name !== 'table') return false;
          
          // Recalculate max cell count
          let newMaxCellCount = 0;
          updatedNode.forEach((child: any) => {
            if (child.type.name === 'tableRowGroup') {
              child.forEach((row: any) => {
                if (row.type.name === 'tableRow') {
                  if(row.childCount > newMaxCellCount) {
                    newMaxCellCount = row.childCount;
                  }
                }
              });
            } else if (child.type.name === 'tableRow') {
              if(child.childCount > newMaxCellCount) {
                newMaxCellCount = child.childCount;
              }
            }
          });
          
          if (newMaxCellCount !== maxCellCount) {
            maxCellCount = newMaxCellCount;
            dom.style.setProperty('--cell-count', maxCellCount.toString());
            // Only re-add handles if structure changed
            setTimeout(addResizeHandles, 50);
          }
          
          return true;
        },
        destroy() {
          dom.removeEventListener('scroll', handleTableScroll, true);
          if (cleanupScrollListener) {
            cleanupScrollListener();
          }
          if (scrollTimeout) {
            clearTimeout(scrollTimeout);
          }
          document.removeEventListener('mousemove', handleMouseMove);
          document.removeEventListener('mouseup', handleMouseUp);
        }
      };
    };
  },
});

export default TablePlus;
