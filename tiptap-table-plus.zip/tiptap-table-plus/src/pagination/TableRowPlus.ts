import TableRow from "@tiptap/extension-table-row";

export const TableRowPlus = TableRow.extend({
  
    addNodeView() {
        return ({ node, editor }) => {
          // Create wrapper for horizontal scroll at row level
          const wrapper = document.createElement('div');
          wrapper.className = 'table-row-wrapper';
          wrapper.style.cssText = `
            overflow-x: auto;
            width: 100%;
            display: block;
            position: relative;
            margin: 0;
            padding: 0;
            scrollbar-width: none;
            -ms-overflow-style: none;
          `;
          
          // Create the actual tr element inside wrapper
          const dom = document.createElement('tr');
          dom.style.display = 'grid';
          
          // Append tr to wrapper
          wrapper.appendChild(dom);
          
          // Scroll sync is now handled by parent table using event delegation
          
          // Default minimum column width
          const defaultColumnWidth = 200;
          
          // Calculate column widths from colwidth attributes
          const calculateColumnWidths = (currentNode: any) => {
            const columnWidths: string[] = [];
            
            currentNode.forEach((cell: any) => {
              const colspan = cell.attrs.colspan || 1;
              const colwidth = cell.attrs.colwidth || [];
              
              for (let i = 0; i < colspan; i++) {
                // Use stored pixel width or default
                const width = colwidth[i] || defaultColumnWidth;
                columnWidths.push(`${width}px`);
              }
            });
            
            // If no widths found, fall back to equal fractions
            if (columnWidths.length === 0) {
              const childCount = currentNode.childCount || 1;
              return `repeat(${childCount}, ${defaultColumnWidth}px)`;
            }
            
            return columnWidths.join(' ');
          };
          
          let currentGridTemplate = calculateColumnWidths(node);
          
          const updateGrid = (gridTemplate: string) => {
            dom.style.gridTemplateColumns = gridTemplate;
          };
      
          updateGrid(currentGridTemplate);
      
          return {
            dom: wrapper,  // Return wrapper as the main DOM element
            contentDOM: dom,  // But content goes into the tr
            ignoreMutation() {
              return document.querySelector('.column-resize-handle') !== null;
            },
      
            update(updatedNode) {
              if (updatedNode.type.name !== 'tableRow') {
                return false;
              }
              
              // Recalculate grid template from updated node
              const newGridTemplate = calculateColumnWidths(updatedNode);
              
              if (newGridTemplate !== currentGridTemplate) {
                currentGridTemplate = newGridTemplate;
                updateGrid(newGridTemplate);
              }
              
              return true;
            },
            
            destroy() {
            }
          };
        };
      },
})

export default TableRowPlus
