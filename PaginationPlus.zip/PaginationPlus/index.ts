import { PaginationPlus } from './PaginationPlus'

export { PaginationPlus }